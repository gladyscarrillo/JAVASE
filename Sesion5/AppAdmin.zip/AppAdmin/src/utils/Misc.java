package utils;


public class Misc {
    public static void asegurarEquipo(int dias){
        System.out.println("El equipo ha sido asegurado por "+dias+" dias");
    }
}
