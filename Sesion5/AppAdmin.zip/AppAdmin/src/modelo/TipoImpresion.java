package modelo;


public enum TipoImpresion {
    LASER,TONER;
}
