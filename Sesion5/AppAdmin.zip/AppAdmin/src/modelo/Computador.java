package modelo;


public class Computador extends Equipo {
    String pantalla;
    String disco;
    String memoria;
    String procesador;
    String sistemaOperativo;
    String caracteristicasAd;



    public Computador(String codigo, String descripcion, String marca, float precioAlquiler,String pantalla, String disco, String memoria, String procesador, String sistemaOperativo, String caracteristicasAd) {
        super(codigo, descripcion, marca, precioAlquiler);
        this.pantalla = pantalla;
        this.disco = disco;
        this.memoria = memoria;
        this.procesador = procesador;
        this.sistemaOperativo = sistemaOperativo;
        this.caracteristicasAd = caracteristicasAd;
    }

    @Override
    public String toString() {
        return "Computador " + super.toString() + ",pantalla=" + pantalla + ", disco=" + disco ;
    }

    @Override
    public float calcularValorAlquiler(int dias) {
        return dias*getPrecioAlquiler();
    }
    
    
    
}
