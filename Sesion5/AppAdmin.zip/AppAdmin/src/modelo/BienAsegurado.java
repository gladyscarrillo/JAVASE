package modelo;

public interface BienAsegurado {
    void asegurar(int dias);
}
