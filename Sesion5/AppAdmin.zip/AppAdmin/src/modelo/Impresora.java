package modelo;


public class Impresora extends Equipo{
    private TipoImpresion tipoImpresion;
    private boolean conexionWIFI;

    public Impresora( String codigo, String descripcion, String marca, float precioAlquiler,TipoImpresion tipoImpresion, boolean conexionWIFI) {
        super(codigo, descripcion, marca, precioAlquiler);
        this.tipoImpresion = tipoImpresion;
        this.conexionWIFI = conexionWIFI;
    }

    @Override
    public String toString() {
        return "Impresora:" + super.toString() + " tipoImpresion=" + tipoImpresion + ", conexionWIFI=" + conexionWIFI ;
    }
    
    @Override
    public float calcularValorAlquiler(int dias) {
       
        float valor = dias*getPrecioAlquiler();
        //TODO:Calcular valor extra si son mas de 2 dias
        
        return valor;
    }
}
