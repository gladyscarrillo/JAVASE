package interfaz;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import modelo.Cliente;
import modelo.Computador;
import modelo.Equipo;
import modelo.Impresora;
import modelo.TipoImpresion;

public class AppAdmin {
    ArrayList<Equipo> equipos;
    ArrayList<Cliente> clientes;


    public AppAdmin() {
        equipos = new ArrayList<>();
        clientes = new ArrayList<>();

    }
    public static void main(String[] args) {
        // TODO code application logic here
        AppAdmin app = new AppAdmin();
        //cargar los clientes del archivo
        app.cargarClientes();
        System.out.println(app.clientes);

    }
    
    public void cargarClientes() {
        try {
        	//objeto para hacer referencia al archivo
            FileReader reader = new FileReader("archivos/clientes.csv");
            BufferedReader bufferedReader = new BufferedReader(reader);
 
            String line;//variable para ir almacenando una linea del archivo
 
            while ((line = bufferedReader.readLine()) != null) {//se itera hasta que llega al fin del archivo
                System.out.println(line);
                String[] datos = line.split(",");//se separan los campos por ,
                Cliente cliente = new Cliente(datos[0],datos[1],datos[2],datos[3]);// se crea el objeto
                clientes.add(cliente);
            }
            reader.close();
 
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    
}
