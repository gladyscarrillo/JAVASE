package test;

public class BicicletaMontanera extends Bicicleta {
	private int alturaAsiento;
	
	public BicicletaMontanera(int marcha, int velocidad, int alturaAsiento) {
		super(marcha,velocidad);		
		this.alturaAsiento = alturaAsiento;
		//this.velocidad=30;
		
		
	}
	
	@Override
	public String toString() {
	
		return super.toString() + " alturaAsiento"+alturaAsiento;
	}
	//sobre escritura del metodo de la clase padre para cambiar el comportamiento
	@Override
	public void cambiarVelocidad(int valor) {
		this.velocidad-=valor;
	}
	
	public void cambiarPiezas() {
		System.out.println("Cambiando piezas");
	}
	

}
