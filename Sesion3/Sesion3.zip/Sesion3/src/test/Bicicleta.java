package test;

public abstract class Bicicleta {
	private int marcha;
	protected int velocidad;
	
	public Bicicleta(int marcha,int velocidad) {
		this.marcha = marcha;
		this.velocidad = velocidad;
	}
	
	public void setMarcha(int marcha) {
		this.marcha = marcha;
	}
	
	public int getMarcha() {
		return marcha;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}
	
	public void acelerar(int incremento) {
		this.velocidad+=incremento;
		//this.velocidad= this.velocidad + incremento;
	}
	
	public void frenar(int decremento) {
		this.velocidad-=decremento;
	}
	//ejemplo de sobrecarga metodo cambiarVelocidad
	public void cambiarVelocidad(int valor, String accion) {
		if (accion.equals("aumentar")){
			this.velocidad+=valor;
		}else {
			this.velocidad-=valor;
		}
	}
	
	public void cambiarVelocidad(int valor) {
		this.velocidad+=valor;
		
	}
	
	//metodos staticos no se pueden sobreescribir
	public static void vender() {
		
	}
	//metodos abstractos, las clases hijas son las que los implementaran
	//public abstract void cambiarPiezas();
	
	public String toString() {
		return "Bicicleta: marcha="+marcha +" velocidad="+velocidad;
	}
	
}
