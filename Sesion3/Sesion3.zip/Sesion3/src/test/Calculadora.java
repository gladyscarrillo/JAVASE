package test;
//clase de ejemplo de uso de keywords static y final
public class Calculadora {
	private String marca;
	public static final float PI=3.1416f;
	public static String proveedor;
	
	public Calculadora(String marca) {
		this.marca = marca;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	
	@Override
	public String toString() {
		return "Calculadora [marca=" + marca + " PI="+ PI + "Proveedor="+ proveedor+ "]";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculadora calc1 = new Calculadora("HP");
		calc1.proveedor = "Prov1";
		Calculadora calc2 = new Calculadora("Casio");
		calc2.proveedor = "Prov2";
		
		System.out.println(calc1);
		System.out.println(calc2);
		System.out.println(Calculadora.PI);
		System.out.println(Calculadora.proveedor);
		
	}

}
