package test;

public class BicicletaCarrera extends Bicicleta {
	private float peso;

	public BicicletaCarrera(int marcha, int velocidad,float peso) {
		super(marcha,velocidad);
		this.peso = peso;
	}

	@Override
	public String toString() {
		return super.toString() + " peso=" + peso ;
	}
	//metodo propio de la clase
	public void registrar() {
		System.out.println("Metodo registrar");
	}
	
	

}
