package interfaz;

import java.util.ArrayList;

import test.Bicicleta;
import test.BicicletaCarrera;
import test.BicicletaMontanera;

public class TestBicicleta {

	public static void main(String[] args) {
		//arraylist de Bicicleta me permite tener varios tipos de bicicletas
		ArrayList<Bicicleta> listaBici = new ArrayList<>(); 
		
		// TODO Auto-generated method stub
		//Bicicleta bici1 = new Bicicleta(5,100);
		//bici1.frenar(10);
		//bici1.cambiarVelocidad(20, "aumentar");
		//System.out.println(bici1);
		
		BicicletaMontanera bici2 = new BicicletaMontanera(3,100,25);
		bici2.acelerar(20);
		//System.out.println(bici2);
		bici2.cambiarVelocidad(50);
		
		//System.out.println(bici2);
		listaBici.add(bici2);
		BicicletaCarrera bici3 = new BicicletaCarrera(3,100,50);
		listaBici.add(bici3);
		bici3.registrar();
		//el siguiente tipo bicicleta se declara con el tipo de la clase base
		Bicicleta bici4 = new BicicletaCarrera(3,120,60);
		listaBici.add(bici4);
		//para tener acceso al metodo registrar hay que hacer downcasting
		BicicletaCarrera bici5 =((BicicletaCarrera)bici4); 
		bici5.registrar();
		
		for(Bicicleta b:listaBici) {
			System.out.println(b);
		}
		
		//iteracion usando for
		for(int i=0;i<listaBici.size();i++) {
			Bicicleta b = listaBici.get(i);
			System.out.println(b);
		}
	}

}
