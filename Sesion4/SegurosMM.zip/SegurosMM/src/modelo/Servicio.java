/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Gladys
 */
public class Servicio {
    private String codigo;
    private String nombre;
    private String descripcion;
    private float valorVenta;
    
    public Servicio(){
        
    }
    public Servicio(String codigo, String nombre,String descripcion,float valorVenta){
        this.codigo=codigo;
        this.nombre=nombre;
        this.descripcion = descripcion;
        this.valorVenta = valorVenta;
    }
    public Servicio(String codigo, String nombre, float valorVenta){
        this.codigo=codigo;
        this.nombre=nombre;
        this.descripcion = nombre;
        this.valorVenta = valorVenta;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getValorVenta() {
        return valorVenta;
    }

    public void setValorVenta(float valorVenta) {
        this.valorVenta = valorVenta;
    }
    
    public String toString(){
        return "Servicio: codigo=" + codigo+ " nombre="+nombre;
    }
    
    
}
