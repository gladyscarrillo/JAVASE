package modelo;

public class Cliente extends Persona{
	private Vendedor vendedorAsignado;
	
	public Cliente(String cedula, String nombre, String direccion, String telefono) {
		super(cedula, nombre, direccion, telefono);
		// TODO Auto-generated constructor stub
	}

	public Vendedor getVendedorAsignado() {
		return vendedorAsignado;
	}

	public void setVendedorAsignado(Vendedor vendedorAsignado) {
		this.vendedorAsignado = vendedorAsignado;
	}

	@Override
	public String toString() {
		return super.toString() + " vendedorAsignado=" + vendedorAsignado.getNombre() ;
	}

	
}
