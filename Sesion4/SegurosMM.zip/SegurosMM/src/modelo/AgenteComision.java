package modelo;

import java.util.ArrayList;

public interface AgenteComision {
	double calcularComision(ArrayList<Venta> ventas);
}
