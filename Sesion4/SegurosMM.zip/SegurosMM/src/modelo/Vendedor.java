package modelo;

import java.util.ArrayList;

public class Vendedor extends Persona implements AgenteComision{
	private double porcentajeComision;
	private double sueldo;
	

	public Vendedor(String cedula, String nombre, 
			String direccion, String telefono, 
			double porcentajeComision, double sueldo) {
		
		super(cedula, nombre, direccion, telefono);
		// TODO Auto-generated constructor stub
		this.porcentajeComision = porcentajeComision;
		this.sueldo = sueldo;
	}

	public String toString() {
		return super.toString()+" sueldo ="+sueldo;
	}

	public double getPorcentajeComision() {
		return porcentajeComision;
	}

	public void setPorcentajeComision(double porcentajeComision) {
		this.porcentajeComision = porcentajeComision;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public double calcularComision(ArrayList<Venta> ventas) {
		// TODO Auto-generated method stub
                double comision=0;
                for (Venta v:ventas){
                    // verificar si la venta le pertenece a ese vendedor
                    if (v.getCliente().getVendedorAsignado().getCedula().equals(this.getCedula()) ){
                        //calcular comision
                        comision+=porcentajeComision*v.getServicio().getValorVenta();
                    }
                }
		return comision;
	}



	
}
