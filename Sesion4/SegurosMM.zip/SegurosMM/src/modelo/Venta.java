package modelo;

import java.util.Date;

public class Venta {
    private Servicio servicio;
    private Cliente cliente;
    private Date fecha;
    
    public Venta(Servicio servicio,Cliente cliente){
        this.servicio = servicio;
        this.cliente = cliente;
        fecha = new Date();
    }
    public String toString(){
        return "Venta :"+servicio + " " + cliente;
    }

    public Servicio getServicio() {
        return servicio;
    }

    public void setServicio(Servicio servicio) {
        this.servicio = servicio;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
}
