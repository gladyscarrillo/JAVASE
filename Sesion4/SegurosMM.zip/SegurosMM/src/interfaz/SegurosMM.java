/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

/**
 *
 * @author Gladys
 */

import java.util.ArrayList;
import modelo.*;//importar todas las clases del paquete

public class SegurosMM {
	ArrayList<Cliente> clientes;
	ArrayList<Vendedor> vendedores;
	ArrayList<Servicio> servicios;
	ArrayList<Venta> ventas;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SegurosMM app = new SegurosMM();
		app.clientes = new ArrayList<>();
		app.vendedores = new ArrayList<>();
		app.ventas = new ArrayList<>();
		app.servicios = new ArrayList<>();

		// crear objetos servicios
		Servicio serv1 = new Servicio("1001", "Basico", 300);
		Servicio serv2 = new Servicio("1002", "Premium", 500);
		app.servicios.add(serv1);
		app.servicios.add(serv2);

		//crear clientes
		app.clientes.add(new Cliente("12312321", "Gladys", "2432432", "Gye"));
		app.clientes.add(new Cliente("234324", "Juan Pueblo", "424325", "Gye"));
		Cliente cliente = new Cliente("2542524", "Jaime", "543534", "Gye");
		app.clientes.add(cliente);
		// System.out.println(app.clientes);
		//crear vendedores
		app.vendedores.add(new Vendedor("23121321", "Vendedor 1", "233223", "TIA", 0.05, 400));
		app.vendedores.add(new Vendedor("54354354", "Vendedor 2", "233223", "TIA", 0.05, 400));
		app.vendedores.add(new Vendedor("3453534", "Vendedor 3", "233223", "TIA", 0.1, 800));

		//asignar vendedores usando foreach
		int j = 0;
		for (Vendedor vend : app.vendedores) {
			System.out.println(vend);
			app.clientes.get(j).setVendedorAsignado(vend);
			j++;
		}
		//asignar vendedores usando for con variable para indice
		for (int i = 0; i < app.vendedores.size(); i++) {
			System.out.println(app.vendedores.get(i));
			// asignar a cliente un vendedor
			app.clientes.get(i).setVendedorAsignado(app.vendedores.get(i));
		}
		System.out.println(app.clientes);
		// llamar a simular ventas
		app.simularVentas();
		System.out.println(app.ventas);
		//calcular la comision de los vendedores
		for (Vendedor vend : app.vendedores) {
			double comision = vend.calcularComision(app.ventas);
			System.out.println(vend + "Comision:" + comision);
		}

	}

	public void simularVentas() {
		for (int i = 0; i < clientes.size(); i++) {
			// el servicio basico esta en el indice 0
			Venta venta = new Venta(servicios.get(0), clientes.get(i));
			ventas.add(venta);
			// ventas.add(new Venta(servicios.get(0),clientes.get(i)));
		}
	}

}
